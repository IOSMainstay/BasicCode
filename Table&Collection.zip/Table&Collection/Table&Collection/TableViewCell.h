//
//  TableViewCell.h
//  Table&Collection
//
//  Created by 九山九日 on 16/4/21.
//  Copyright © 2016年 jiushanjiuri. All rights reserved.
//

#import <UIKit/UIKit.h>
//@class CollectionViewCell;
@class TableViewCell;
@protocol TableViewCellDelegate <NSObject>

- (void)TableViewCell:(TableViewCell *)cell collectionView:(UICollectionView *)Collection IndexPath:(NSIndexPath *)indexpath;

@end

@interface TableViewCell : UITableViewCell<UICollectionViewDelegate,UICollectionViewDataSource>

@property (nonatomic ,assign) id<TableViewCellDelegate>delegate;

@property (nonatomic ,assign)NSInteger RowNum;

@property (nonatomic ,copy)NSMutableArray *ItenLabelTextArr;

@end
