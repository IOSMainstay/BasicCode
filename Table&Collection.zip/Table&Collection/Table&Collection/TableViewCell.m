//
//  TableViewCell.m
//  Table&Collection
//
//  Created by 九山九日 on 16/4/21.
//  Copyright © 2016年 jiushanjiuri. All rights reserved.
//

#import "TableViewCell.h"
#import "CollectionViewCell.h"
static NSString *cellID = @"TableCollectionCell";
@implementation TableViewCell
{
    UICollectionView *collection;
    UICollectionViewFlowLayout *Layout;
}
- (void)awakeFromNib {
    // Initialization code
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        Layout = [[UICollectionViewFlowLayout alloc]init];
        [Layout setScrollDirection:UICollectionViewScrollDirectionVertical];
        collection = [[UICollectionView alloc]initWithFrame:CGRectMake(10, 5, CGRectGetWidth([UIScreen mainScreen].bounds)-20, 40*3) collectionViewLayout:Layout];
        collection.scrollEnabled = NO;
        collection.backgroundColor = [UIColor grayColor];
        collection.delegate = self;
        collection.dataSource = self;
        collection.layer.cornerRadius = 10;
        collection.layer.borderWidth = 1;
        collection.layer.borderColor = [UIColor grayColor].CGColor;
        collection.layer.masksToBounds = YES;
        [self addSubview:collection];
        
        [collection registerClass:[CollectionViewCell class] forCellWithReuseIdentifier:cellID];
        
    }
    return self;
}
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    NSLog(@"_RowNum_RowNum_RowNum_RowNum%lD",(long)_RowNum);
    
    return 4*_RowNum;
}
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    CollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:cellID forIndexPath:indexPath];
    cell.backgroundColor = [UIColor grayColor];
    if (!cell) {
        NSLog(@"新建失败");
    }
    NSLog(@"%ld",_ItenLabelTextArr.count);
    NSInteger row = indexPath.row;
    if (_ItenLabelTextArr.count%4==0) {
        cell.Label.text = _ItenLabelTextArr[row];
    }else{
        NSInteger countNum = _ItenLabelTextArr.count%4;
        for (int index = 0; index < 4-countNum; index ++) {
            [_ItenLabelTextArr addObject:@""];
        }
        NSLog(@"%@%ld",_ItenLabelTextArr,row);
        cell.Label.text = _ItenLabelTextArr[row];
    }
    return cell;
}
#pragma mark collectionView Delegate
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    return CGSizeMake((CGRectGetWidth([UIScreen mainScreen].bounds)-20)/4, (CGRectGetHeight(self.frame)-10)/_RowNum);
}
//设置上左下右的间隔
- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
    
    return UIEdgeInsetsMake(0, 0, 0, 0);
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section{

    return 0;
}
//纵轴的间距
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section{
    return 0;
}
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    [self.delegate TableViewCell:self collectionView:collection IndexPath:indexPath];
}

- (void)setRowNum:(NSInteger)RowNum{
    _RowNum = RowNum;
    collection.frame = CGRectMake(10, 5, CGRectGetWidth([UIScreen mainScreen].bounds)-20, 40*RowNum);
//    NSLog(@"%d",RowNum);
//    Layout.itemSize = CGSizeMake((CGRectGetWidth([UIScreen mainScreen].bounds)-20)/4, (CGRectGetHeight(self.frame)-10)/RowNum);
//    collection.
}
- (void)setItenLabelTextArr:(NSMutableArray *)ItenLabelTextArr{
    _ItenLabelTextArr = [NSMutableArray array];
    _ItenLabelTextArr = ItenLabelTextArr;
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
