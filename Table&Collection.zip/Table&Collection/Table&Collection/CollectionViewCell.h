//
//  CollectionViewCell.h
//  Table&Collection
//
//  Created by 九山九日 on 16/4/21.
//  Copyright © 2016年 jiushanjiuri. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CollectionViewCell : UICollectionViewCell

@property (nonatomic,strong) UILabel *Label;

@end
