//
//  TableViewController.m
//  Table&Collection
//
//  Created by 九山九日 on 16/4/21.
//  Copyright © 2016年 jiushanjiuri. All rights reserved.
//

#import "TableViewController.h"
#import "TableViewCell.h"
@interface TableViewController ()<TableViewCellDelegate>
{
//    NSArray *aa;
    NSArray *Value;
}
@end

@implementation TableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
//    aa = @[@(3),@(2),@(4),@(3),@(2)];
    NSString *Path = [[NSBundle mainBundle]pathForResource:@"aroundList.plist" ofType:nil];
    Value = [[NSArray array]initWithContentsOfFile:Path];
    
    NSLog(@"%@",Value);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
#warning Incomplete implementation, return the number of sections
    return Value.count;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 10;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
#warning Incomplete implementation, return the number of rows
    return 1;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellID = @"cellid";
    TableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    if (!cell) {
        cell = [[TableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cellorg"];
    }
    cell.delegate = self;
    NSInteger section = indexPath.section;
    cell.RowNum = round([Value[section][@"titleList"] count]/4.0+0.49);//获取每个cell中的Item的行数
    NSMutableArray *arr = [Value[section][@"titleList"] mutableCopy];
    cell.ItenLabelTextArr = arr;
    return cell;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSInteger section = indexPath.section;
    NSInteger ItemRow = round([Value[section][@"titleList"] count]/4.0+0.49);
    return 40*ItemRow+10;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 44;
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    UIView *BGView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, CGRectGetWidth([UIScreen mainScreen].bounds), 44)];
    BGView.backgroundColor = [UIColor whiteColor];
    [tableView addSubview:BGView];
    
    UIButton *Button = [UIButton buttonWithType:UIButtonTypeCustom];
    Button.frame = CGRectMake(0, 0, CGRectGetWidth(BGView.frame), 44);
    Button.enabled = NO;
    [Button setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
    [Button setImage:[UIImage imageNamed:@"1"] forState:UIControlStateNormal];
    [Button setTitle:Value[section][@"headerTitle"] forState:UIControlStateNormal];
    [BGView addSubview:Button];
    
    return BGView;
}
#pragma mark TableViewCellDelegate
- (void)TableViewCell:(TableViewCell *)cell collectionView:(UICollectionView *)Collection IndexPath:(NSIndexPath *)indexpath{
    
    NSIndexPath *IndexPath = [self.tableView indexPathForCell:cell];
    NSLog(@"%ld,%ld",(long)IndexPath.section,(long)indexpath.row);
//    switch (IndexPath.section) {
//        case 0:
//            switch (indexpath.row) {
//                case 0:
//                    NSLog(@"%ld,%ld",(long)IndexPath.section,(long)indexpath.row);
//                    break;
//                case 1:
//                    NSLog(@"1");
//                    break;
//                case 2:
//                    NSLog(@"2");
//                    break;
//                    
//                default:
//                    break;
//            }
//            break;
//        case 1:
//            switch (indexpath.row) {
//                case 0:
//                    NSLog(@"0");
//                    break;
//                case 1:
//                    NSLog(@"1");
//                    break;
//                case 2:
//                    NSLog(@"2");
//                    break;
//                    
//                default:
//                    break;
//            }
//            break;
//        case 2:
//            switch (indexpath.row) {
//                case 0:
//                    NSLog(@"0");
//                    break;
//                case 1:
//                    NSLog(@"1");
//                    break;
//                case 2:
//                    NSLog(@"2");
//                    break;
//                    
//                default:
//                    break;
//            }
//            break;
//            
//        default:
//            break;
//    }
    
    
}
/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
