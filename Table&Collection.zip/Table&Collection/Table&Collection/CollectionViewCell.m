
//
//  CollectionViewCell.m
//  Table&Collection
//
//  Created by 九山九日 on 16/4/21.
//  Copyright © 2016年 jiushanjiuri. All rights reserved.
//

#import "CollectionViewCell.h"

@implementation CollectionViewCell

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        _Label = [[UILabel alloc]initWithFrame:CGRectMake(0.5, 0.5, CGRectGetWidth(self.frame)-1, CGRectGetHeight(self.frame)-1)];
        _Label.textAlignment = NSTextAlignmentCenter;
        _Label.textColor = [UIColor blackColor];
        _Label.backgroundColor = [UIColor whiteColor];
        _Label.font = [UIFont systemFontOfSize:14];
        [self.contentView addSubview:_Label];
        
    }
    return self;
}

@end
